#include <iostream>

using namespace std;

int main()
{
    // {{ }}  {x}
    std::cout << "0 means 'success' \a " << std::endl; // `chr(96)`
    return 0; // return 'success'
}
