#include <iostream>

using namespace std;

int main(int argc, char **argv)
{
#py if False:
#py else:
#py elif False:
#py endif
    return 0;
}

