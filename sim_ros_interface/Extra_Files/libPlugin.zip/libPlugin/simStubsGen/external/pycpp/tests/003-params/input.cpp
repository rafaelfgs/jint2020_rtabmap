struct Test {
#py for k, v in pycpp.params.items():
    `v` `k`;
#py endfor
};
