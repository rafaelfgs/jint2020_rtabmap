struct Test {
    int a;
    float b;
};
